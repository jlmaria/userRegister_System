package view;

public class Run_System {

    public static void main(String[] args) {

        Register.run(args);

    }
}