module userRegister.System {

    requires javafx.base;
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires javafx.media;
    requires javafx.swing;
    requires javafx.swt;
    requires javafx.web;
    requires java.sql;
    requires mysql.connector.java;

    opens view;
    exports controller;
    opens controller;

}